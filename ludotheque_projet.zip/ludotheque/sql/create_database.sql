-- ==============================================
-- Base de données : Ludothèque
-- Script de création des tables
-- ==============================================

CREATE DATABASE IF NOT EXISTS ludotheque CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ludotheque;

-- Table Utilisateurs
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    statut ENUM('membre', 'non_membre') NOT NULL DEFAULT 'non_membre',
    role ENUM('utilisateur', 'admin', 'president') NOT NULL DEFAULT 'utilisateur',
    role_bureau VARCHAR(100) DEFAULT NULL,
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table Jeux
CREATE TABLE jeux (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    description TEXT,
    image_principale VARCHAR(255),
    joueurs_min INT NOT NULL,
    joueurs_max INT NOT NULL,
    temps_jeu_minutes INT NOT NULL,
    difficulte_apprentissage ENUM('facile', 'moyen', 'difficile') NOT NULL,
    difficulte_jeu ENUM('facile', 'moyen', 'difficile') NOT NULL,
    regles_url VARCHAR(500),
    statut ENUM('en_stock', 'emprunte', 'loue', 'perdu', 'indisponible') NOT NULL DEFAULT 'en_stock',
    date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table Images Jeux (plusieurs images par jeu)
CREATE TABLE images_jeux (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jeu_id INT NOT NULL,
    chemin VARCHAR(255) NOT NULL,
    FOREIGN KEY (jeu_id) REFERENCES jeux(id) ON DELETE CASCADE
);

-- Table Événements
CREATE TABLE evenements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    description TEXT,
    date_evenement DATETIME NOT NULL,
    lieu VARCHAR(255) NOT NULL,
    categorie ENUM('salle_du_jeudi', 'jeu_du_jeudi', 'soiree_jeux', 'occasionnel') NOT NULL,
    image VARCHAR(255),
    cree_par INT NOT NULL,
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cree_par) REFERENCES utilisateurs(id)
);

-- Table Demandes (emprunts, locations, réservations)
CREATE TABLE demandes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    jeu_id INT NOT NULL,
    type_demande ENUM('emprunt', 'location', 'reservation') NOT NULL,
    statut ENUM('en_attente', 'validee', 'refusee') NOT NULL DEFAULT 'en_attente',
    date_debut DATE NOT NULL,
    date_fin DATE,
    date_evenement DATE DEFAULT NULL,
    duree_semaines INT DEFAULT NULL,
    date_demande DATETIME DEFAULT CURRENT_TIMESTAMP,
    traite_par INT DEFAULT NULL,
    date_traitement DATETIME DEFAULT NULL,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id),
    FOREIGN KEY (jeu_id) REFERENCES jeux(id),
    FOREIGN KEY (traite_par) REFERENCES utilisateurs(id)
);

-- Table Infos Bureau (mandat)
CREATE TABLE bureau_mandat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL
);
