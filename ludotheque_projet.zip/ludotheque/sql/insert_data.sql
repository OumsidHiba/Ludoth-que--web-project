-- ==============================================
-- Données de test — Ludothèque
-- ==============================================
USE ludotheque;

INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, statut, role, role_bureau) VALUES
('Dupont', 'Jean', 'jean.dupont@ece.fr', '$2y$10$placeholder', 'membre', 'president', 'Président'),
('Lemoine', 'Alice', 'alice.lemoine@ece.fr', '$2y$10$placeholder', 'membre', 'admin', 'Trésorière'),
('Roux', 'Thomas', 'thomas.roux@ece.fr', '$2y$10$placeholder', 'membre', 'admin', 'Vice-président'),
('Blanc', 'Camille', 'camille.blanc@ece.fr', '$2y$10$placeholder', 'membre', 'admin', 'Secrétaire'),
('Martin', 'Marie', 'marie.martin@ece.fr', '$2y$10$placeholder', 'membre', 'utilisateur', NULL),
('Bernard', 'Luc', 'luc.bernard@ece.fr', '$2y$10$placeholder', 'non_membre', 'utilisateur', NULL);

INSERT INTO jeux (nom, description, joueurs_min, joueurs_max, temps_jeu_minutes, difficulte_apprentissage, difficulte_jeu, statut) VALUES
('Catan', 'Jeu de stratégie et de commerce.', 3, 4, 60, 'moyen', 'moyen', 'en_stock'),
('Dixit', 'Jeu de cartes poétique et imaginatif.', 3, 6, 30, 'facile', 'facile', 'en_stock'),
('Terraforming Mars', 'Colonisez la planète Mars.', 1, 5, 120, 'difficile', 'difficile', 'emprunte'),
('7 Wonders', 'Construisez une civilisation en 3 âges.', 2, 7, 30, 'moyen', 'moyen', 'loue'),
('Codenames', 'Jeu d''association de mots en équipe.', 4, 8, 15, 'facile', 'facile', 'en_stock'),
('Pandemic', 'Coopérez pour sauver le monde.', 2, 4, 45, 'moyen', 'moyen', 'en_stock');

INSERT INTO evenements (titre, description, date_evenement, lieu, categorie, cree_par) VALUES
('Salle ouverte', 'La salle est ouverte à tous.', '2026-03-13 12:00:00', 'Salle B12', 'salle_du_jeudi', 1),
('Tournoi de Catan', 'Tournoi amical ouvert à tous.', '2026-03-20 18:00:00', 'Salle A3', 'jeu_du_jeudi', 1),
('Soirée Loup-Garou', 'Grande soirée au Hall.', '2026-03-21 20:00:00', 'Hall principal', 'soiree_jeux', 2),
('Escape Game géant', 'Escape Game sur le campus.', '2026-03-22 14:00:00', 'Amphithéâtre', 'occasionnel', 3);

INSERT INTO bureau_mandat (date_debut, date_fin) VALUES ('2025-09-01', '2026-06-30');
