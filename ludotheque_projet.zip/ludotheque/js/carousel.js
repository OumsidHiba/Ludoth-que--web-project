// Carrousel événements page d'accueil
