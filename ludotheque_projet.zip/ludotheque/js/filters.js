// Filtrage dynamique du catalogue de jeux
