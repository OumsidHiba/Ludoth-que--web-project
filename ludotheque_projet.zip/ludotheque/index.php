<?php require_once "php/includes/header.php"; ?>
<!-- Hero + Présentation + 4 blocs événements + Contact -->
<?php require_once "php/includes/footer.php"; ?>
