<?php // AuthController — login(), register(), logout() ?>
