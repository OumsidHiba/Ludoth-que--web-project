<?php // EvenementController — liste(), detail(), creer(), modifier(), supprimer() ?>
