<?php // JeuController — liste(), fiche(), ajouter(), modifier(), supprimer(), filtrer() ?>
