<?php // DemandeController — creerEmprunt(), creerLocation(), creerReservation(), accepter(), refuser() ?>
