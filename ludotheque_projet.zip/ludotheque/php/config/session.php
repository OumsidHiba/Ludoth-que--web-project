<?php
session_start();
function isLoggedIn() { return isset($_SESSION['user_id']); }
function getUserRole() { return $_SESSION['role'] ?? null; }
function requireLogin() { if (!isLoggedIn()) { header("Location: /php/views/auth/connexion.php"); exit(); } }
function requireAdmin() { requireLogin(); if (!in_array(getUserRole(), ['admin','president'])) { header("Location: /index.php"); exit(); } }
function requirePresident() { requireLogin(); if (getUserRole() !== 'president') { header("Location: /index.php"); exit(); } }
?>
