<?php require_once __DIR__ . '/../config/session.php'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ludothèque</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/responsive.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
    <nav>
        <div class="logo">Ludothèque</div>
        <ul>
            <li><a href="/index.php">Accueil</a></li>
            <li><a href="/php/views/evenements/liste.php">Événements</a></li>
            <li><a href="/php/views/ludotheque/catalogue.php">Ludothèque</a></li>
            <li><a href="/php/views/apropos/index.php">À propos</a></li>
            <li><a href="/php/views/contact/index.php">Contact</a></li>
            <?php if (isLoggedIn()): ?>
                <li><a href="/php/views/compte/index.php">Mon Compte</a></li>
            <?php else: ?>
                <li><a href="/php/views/auth/connexion.php">Connexion</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
<main>
