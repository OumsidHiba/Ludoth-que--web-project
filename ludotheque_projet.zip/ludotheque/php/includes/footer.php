</main>
<footer>
    <p>© 2026 Ludothèque — Association étudiante ECE</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="/js/main.js"></script>
</body>
</html>
