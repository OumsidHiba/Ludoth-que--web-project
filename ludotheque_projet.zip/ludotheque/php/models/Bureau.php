<?php // Modèle Bureau — getMembres(), addAdmin(), removeAdmin(), updateRole(), getInfosMandat() ?>
