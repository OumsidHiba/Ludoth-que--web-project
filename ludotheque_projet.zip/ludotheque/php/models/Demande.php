<?php // Modèle Demande — create(), getByUserId(), getAll(), accepter(), refuser(), getEnAttente() ?>
