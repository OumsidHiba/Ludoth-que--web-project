<?php // Modèle Utilisateur — register(), login(), getById(), updateProfile(), getAll(), updateRole(), delete() ?>
