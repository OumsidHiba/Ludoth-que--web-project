<?php // Modèle Événement — getAll(), getById(), create(), update(), delete(), getByCategorie() ?>
