<?php // Modèle Jeu — getAll(), getById(), create(), update(), delete(), updateStatut(), filter() ?>
