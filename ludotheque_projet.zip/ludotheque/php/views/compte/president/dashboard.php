<?php /* Dashboard président : hérite admin + gestion bureau + infos internes */ ?>
