<?php
require_once __DIR__ . '/../../config/session.php';
requireLogin();
$role = getUserRole();
if ($role === 'president') { include 'president/dashboard.php'; }
elseif ($role === 'admin') { include 'admin/dashboard.php'; }
else { include 'utilisateur/profil.php'; }
?>
