<?php /* Gestion événements admin : CRUD, 4 catégories */ ?>
