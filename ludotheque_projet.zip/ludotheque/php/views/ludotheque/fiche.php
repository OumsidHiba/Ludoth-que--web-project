<?php require_once __DIR__."/../../includes/header.php"; ?><!-- Fiche jeu : images, infos, statut, boutons action selon rôle --><?php require_once __DIR__."/../../includes/footer.php"; ?>
