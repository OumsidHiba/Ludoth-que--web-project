<?php require_once __DIR__."/../../includes/header.php"; ?><!-- Catalogue jeux + filtres joueurs/difficulté/durée --><?php require_once __DIR__."/../../includes/footer.php"; ?>
