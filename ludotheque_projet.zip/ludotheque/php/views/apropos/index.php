<?php require_once __DIR__."/../../includes/header.php"; ?><!-- Histoire, valeurs, fonctionnement, règles --><?php require_once __DIR__."/../../includes/footer.php"; ?>
