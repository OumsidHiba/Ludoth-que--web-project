<?php require_once __DIR__."/../../includes/header.php"; ?><!-- Formulaire inscription : nom, prénom, email, mdp, statut --><?php require_once __DIR__."/../../includes/footer.php"; ?>
