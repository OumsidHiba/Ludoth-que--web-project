<?php require_once __DIR__."/../../includes/header.php"; ?><!-- Liste événements, filtres type/date --><?php require_once __DIR__."/../../includes/footer.php"; ?>
