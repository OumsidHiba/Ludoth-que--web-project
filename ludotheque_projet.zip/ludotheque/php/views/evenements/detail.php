<?php require_once __DIR__."/../../includes/header.php"; ?><!-- Détail événement : image, titre, date, lieu, description --><?php require_once __DIR__."/../../includes/footer.php"; ?>
