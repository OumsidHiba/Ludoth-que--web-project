# Ludothèque — Association étudiante ECE

## Technologies
- Front-end : HTML5, CSS3, Bootstrap, JavaScript, jQuery, AJAX
- Back-end : PHP
- Base de données : MySQL
- Versioning : Git

## Installation
1. Cloner le dépôt
2. Importer sql/create_database.sql puis sql/insert_data.sql
3. Configurer php/config/database.php
4. Lancer serveur local (XAMPP/WAMP)
5. Accéder à http://localhost/ludotheque/
